<?php $__env->startSection('content'); ?>
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title">Property</h4>
                    </div>
                    <div class="col-7 align-self-center">
                        <div class="d-flex align-items-center justify-content-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="<?php echo e(route('admin.index')); ?>">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Property</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid test">
                <div class="row">
                <div class="col-12 test23">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">All Property</h4>
                                <a href="<?php echo e(route('listings.create')); ?>">Add Property</a>
                            </div>
                            <div class="table-responsive m-t-20">
                                <table id="" class="table table-bordered table-responsive-lg">
                                    <thead>
                                        <tr>

                                            <th scope="col">#</th>
                                            <th scope="col">Title</th>
                                            <th scope="col">Price</th>
                                            <th scope="col">Realtor</th>
                                            <th scope="col">Image</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $published_listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="row_<?php echo e($listing->id); ?>">
                                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                                            <td><?php echo e($listing -> title); ?></td>
                                            <td><?php echo e($listing -> price); ?></td>
                                            <td><?php echo e($listing -> realtor-> name); ?></td>
                                            <td><img src="<?php echo e(url($listing -> thumbnail_0)); ?>" alt="" srcset="" style="width:70px;height:50px"></td>
                                            <td><?php if( $listing -> is_published == '1' ): ?>
                                                    Published
                                                <?php else: ?>
                                                    Un Publish
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($listing -> created_at->diffForHumans()); ?></td>
                                            
                                            <td>
                                            <a href="<?php echo e(route('listings.show', $listing -> id )); ?>"><span class="btn btn-sm btn-rounded btn-success">View</span></a>

                                            
                                            <button onclick="deleteData('<?php echo e(route('listings.destroy', $listing -> id)); ?>','<?php echo e($listing -> id); ?>')" type="submit" class="btn btn-sm btn-rounded btn-danger">Delete</button>

                                        </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
      
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\property\resources\views/admin/layouts/listings/listings.blade.php ENDPATH**/ ?>