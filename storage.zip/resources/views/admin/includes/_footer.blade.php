<!-- Footer -->

<footer class="footer text-center">
    All Rights Reserved
</footer>